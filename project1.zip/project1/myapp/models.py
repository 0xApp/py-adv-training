from django.db import models

class Blog(models.Model):
	title = models.CharField(max_length=120, unique=True)
	author = models.CharField(max_length=60)
	dop = models.DateField(verbose_name="Date of Publishing") # auto_now=True, auto_now_add=True, null=True, default="2021-05-25"
	content = models.TextField(blank=True)
	def __str__(self): # string repr. of object
		return self.title
